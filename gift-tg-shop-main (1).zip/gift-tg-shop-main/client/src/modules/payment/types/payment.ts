export interface IPayment {
  giftId: string
  amount: number
  currency: 'USDT' | 'TON'
} 
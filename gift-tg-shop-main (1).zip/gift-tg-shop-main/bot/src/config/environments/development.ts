export const developmentConfig = {
  logLevel: 'debug' as const,
  enableWebhook: false,
  enablePolling: true,
  apiUrl: 'http://localhost:4000'
} 
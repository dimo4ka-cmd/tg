export const productionConfig = {
  logLevel: 'error' as const,
  enableWebhook: true,
  enablePolling: false,
  apiUrl: 'https://local-tuna-server.ru.tuna.am'
} 